#!/usr/bin/env python  
# -*- coding: utf-8 -*-

import gtk  
import gobject  
import webkit

# Fonction appelée lorsqu'on appuie sur enter dans la barre d'adresse
def browse(widget):
  # On affiche l'URL contenue dans la barre d'adresse
  browser.open(widget.get_text()) 

gobject.threads_init()

# Création de la fenêtre
window = gtk.Window()
# On définit sa taille par défaut
window.set_default_size(800, 600)
# Exécute gtk.main_quit() quand on clique sur la croix
window.connect("destroy", lambda a: gtk.main_quit()) 

# La barre d'adresse et la zone où s'affiche la page internet
# sont placées dans une boîte verticale
vbox = gtk.VBox(False,0)
window.add(vbox)
add = gtk.Entry()
# la fonction browse est appelée quand on tape sur Enter
add.connect("activate", browse)
vbox.pack_start(add, False, True, 0)

# Initialisation de l'objet webkit
browser = webkit.WebView()
vbox.pack_start(browser)

window.show_all()  
gtk.main()  
